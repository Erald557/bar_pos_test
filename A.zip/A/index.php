<?php
require 'config.php'; // Include the database configuration at the top
require 'nav_bar.php'; // Include the navbar

// Fetch table data from the database
$sql = "SELECT table_number, is_occupied FROM tables";
$result = $conn->query($sql);

if (!$result) {
    die("Query failed: " . $conn->error);
}
?>

<div class="table-container">
    <?php if ($result && $result->num_rows > 0): ?>
        <?php while ($row = $result->fetch_assoc()): ?>
            <div class="table" 
                 style="background-color: <?= $row['is_occupied'] ? 'red' : 'green'; ?>" 
                 onclick="handleTableClick(<?= $row['table_number']; ?>, <?= $row['is_occupied'] ?>)">
                Table <?= $row['table_number']; ?>
            </div>
        <?php endwhile; ?>
    <?php else: ?>
        <p>No tables found.</p>
    <?php endif; ?>
</div>

<script>
function handleTableClick(tableNumber, isOccupied) {
    if (isOccupied) {
        // Redirect to a page to view orders or reopen the table
        window.location.href = `order_summary.php?table_number=${tableNumber}`;
    } else {
        // Redirect to order_system.php with the selected table number
        window.location.href = `order_system.php?table_number=${tableNumber}`;
    }
}
</script>


<style>
    body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa; /* Light background color */
           
        }
    .table-container {
        display: flex;
        flex-wrap: wrap;
        justify-content: center; /* Center the tables */
        margin-top: 20px; /* Space above the tables */
    }

    .table {
        width: 100px; /* Width of each table square */
        height: 100px; /* Height of each table square */
        margin: 10px; /* Space between tables */
        display: flex;
        align-items: center; /* Center content vertically */
        justify-content: center; /* Center content horizontally */
        color: white; /* Text color */
        font-weight: bold; /* Make text bold */
        border-radius: 10px; /* Rounded corners */
    }
</style>
