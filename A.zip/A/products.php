<?php
require 'config.php'; // Include database configuration
require 'nav_bar.php'; // Include the navbar

// Handle adding a new product
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_product'])) {
    $product_name = $conn->real_escape_string($_POST['product_name']);
    $category_id = (int)$_POST['category_id'];
    $price = (float)$_POST['price'];
    $stock = (int)$_POST['stock'];

    $sql = "INSERT INTO products (product_name, category_id, price, stock) VALUES ('$product_name', $category_id, $price, $stock)";
    if ($conn->query($sql) === TRUE) {
       
    } else {
        echo "<script>alert('Error: " . $conn->error . "');</script>";
    }
}

// Handle deleting a product
if (isset($_GET['delete_id'])) {
    $delete_id = (int)$_GET['delete_id'];
    $delete_sql = "DELETE FROM products WHERE product_id = $delete_id";

    if ($conn->query($delete_sql) === TRUE) {
      
    } else {
        echo "<script>alert('Error: " . $conn->error . "');</script>";
    }
}

// Fetch existing products from the database
$sql = "SELECT p.product_id, p.product_name, c.category_name, p.price, p.stock FROM products p LEFT JOIN categories c ON p.category_id = c.category_id";
$result = $conn->query($sql);

// Fetch categories for the dropdown
$category_sql = "SELECT category_id, category_name FROM categories";
$category_result = $conn->query($category_sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Products</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa; /* Light background color */
        }

        h2 {
            color: #333; /* Dark color for headings */
        }

        .container {
            display: flex;
            justify-content: space-between;
            max-width: 1200px;
            margin: 0 auto;
        }

        .form-container, .table-container {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            flex: 1;
            margin: 0 10px; /* Margin between containers */
        }

        .form-container {
            margin-right: 20px;
        }

        input[type="text"], input[type="number"], select {
            width: calc(100% - 22px); /* Full width minus padding */
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            margin-bottom: 10px;
        }

        button {
            background-color: #28a745; /* Green for Edit */
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: #218838; /* Darker shade for hover */
        }

        .delete-btn {
            background-color: #dc3545; /* Red for Delete */
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s;
        }

        .delete-btn:hover {
            background-color: #c82333; /* Darker red for hover */
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #007bff; /* Table header color */
            color: white;
        }

        tr:hover {
            background-color: #f1f1f1; /* Highlight on row hover */
        }

        .action-buttons {
            display: flex;
            gap: 5px; /* Space between buttons */
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Add New Product Section -->
        <div class="form-container">
            <h2>Add New Product</h2>
            <form action="" method="POST">
                <input type="text" name="product_name" placeholder="Product Name" required>
                <select name="category_id" required>
                    <option value="">Select Category</option>
                    <?php if ($category_result && $category_result->num_rows > 0): ?>
                        <?php while ($category = $category_result->fetch_assoc()): ?>
                            <option value="<?= $category['category_id']; ?>"><?= htmlspecialchars($category['category_name']); ?></option>
                        <?php endwhile; ?>
                    <?php endif; ?>
                </select>
                <input type="number" name="price" placeholder="Price" step="0.01" required>
                <input type="number" name="stock" placeholder="Stock" min="0" required>
                <button type="submit" name="add_product">Add Product</button>
            </form>
        </div>

        <!-- Existing Products Section -->
        <div class="table-container">
            <h2>Existing Products</h2>
            <table>
                <tr>
                    <th>Product ID</th>
                    <th>Product Name</th>
                    <th>Category</th>
                    <th>Price</th>
                    <th>Stock</th>
                    <th>Actions</th>
                </tr>
                <?php if ($result && $result->num_rows > 0): ?>
                    <?php while ($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?= $row['product_id']; ?></td>
                            <td><?= htmlspecialchars($row['product_name']); ?></td>
                            <td><?= htmlspecialchars($row['category_name']); ?></td>
                            <td><?= number_format($row['price'], 2); ?></td>
                            <td><?= $row['stock']; ?></td>
                            <td class="action-buttons">
                                <a href="edit_product.php?id=<?= $row['product_id']; ?>" class="edit-btn">
                                    <button>Edit</button>
                                </a>
                                <a href="?delete_id=<?= $row['product_id']; ?>" class="delete-btn" onclick="return confirm('Are you sure you want to delete this product?');">
                                    <button class="delete-btn">Delete</button>
                                </a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="6">No products found.</td>
                    </tr>
                <?php endif; ?>
            </table>
        </div>
    </div>

    <?php $conn->close(); // Close the database connection ?>
</body>
</html>
