<?php
// Database connection
require 'config.php';
require 'nav_bar.php'; // Include the navbar

session_start();

// Ensure table number is set
if (!isset($_SESSION['table_number']) && isset($_GET['table_number'])) {
    $_SESSION['table_number'] = intval($_GET['table_number']);
}

if (!isset($_SESSION['table_number'])) {
    die("No table number selected. Please go back and select a table.");
}

$tableNumber = $_SESSION['table_number']; // Table number to be displayed
$userId = $_SESSION['user_id'] ?? null; // Fetch user ID if logged in

// Initialize variables
$categories = [];
$products = [];
$selectedProducts = [];

// Fetch categories and products
function fetchCategories($conn) {
    $sql = "SELECT category_id, category_name FROM categories";
    return $conn->query($sql);
}

function fetchProducts($conn, $categoryId) {
    $categoryId = $conn->real_escape_string($categoryId); // Sanitize input
    $sql = "SELECT * FROM products" . ($categoryId !== 'All' ? " WHERE category_id = '$categoryId'" : "");
    return $conn->query($sql);
}

// Add selected product to the order
if (isset($_POST['add_to_order'])) {
    $productId = intval($_POST['product_id']);
    $quantity = isset($_POST['quantity']) ? intval($_POST['quantity']) : 1; // Get quantity

    // Fetch product details
    $sql = "SELECT * FROM products WHERE product_id = $productId";
    $result = $conn->query($sql)->fetch_assoc();

    // Check if product already exists in the order
    if (isset($_SESSION['selectedProducts'][$productId])) {
        // Update the quantity
        $_SESSION['selectedProducts'][$productId]['quantity'] += $quantity;
    } else {
        // Add new product
        $_SESSION['selectedProducts'][$productId] = [
            'name' => $result['product_name'],
            'price' => $result['price'],
            'quantity' => $quantity,
        ];
    }
}

// Update quantity from the order list
if (isset($_POST['update_quantity'])) {
    $updatedQuantities = $_POST['quantity'];
    foreach ($updatedQuantities as $productId => $quantity) {
        if (isset($_SESSION['selectedProducts'][$productId])) {
            $_SESSION['selectedProducts'][$productId]['quantity'] = intval($quantity);
        }
    }
}

// Delete a product from the order list
if (isset($_POST['delete_product'])) {
    $productId = intval($_POST['product_id']);
    unset($_SESSION['selectedProducts'][$productId]);
}

// Handle payment options
if (isset($_POST['pay'])) {
    if (!$userId) {
        die("User is not logged in.");
    }

    $total = array_sum(array_map(function($product) {
        return $product['price'] * $product['quantity'];
    }, $_SESSION['selectedProducts']));

    $sql = "INSERT INTO orders (user_id, total_amount) VALUES ('$userId', '$total')";
    $conn->query($sql);

    unset($_SESSION['selectedProducts']);
    echo "Order completed.";
}

// Handle pay later
if (isset($_POST['pay_later'])) {
    if (!isset($_SESSION['selectedProducts']) || empty($_SESSION['selectedProducts'])) {
        echo "No products selected.";
        return;
    }

    if (!$userId) {
        echo "User ID is not set.";
        return;
    }

    $total = array_sum(array_map(function($product) {
        return $product['price'] * $product['quantity'];
    }, $_SESSION['selectedProducts']));

    $sql = "INSERT INTO pending_orders (user_id, table_number, total_amount) 
            VALUES ('$userId', '$tableNumber', '$total')";

    if ($conn->query($sql) === TRUE) {
        $updateTableSql = "UPDATE tables SET is_occupied = 1 WHERE table_number = '$tableNumber'";
        $conn->query($updateTableSql);

        unset($_SESSION['selectedProducts']);
        echo "Order saved as pending. The table is now occupied.";
    } else {
        echo "Error saving order: " . $conn->error;
    }
}

// Fetch categories and products
$categoriesResult = fetchCategories($conn);
$categoryId = $_GET['category_id'] ?? 'All';
$productsResult = fetchProducts($conn, $categoryId);

// Prepare categories array
while ($row = $categoriesResult->fetch_assoc()) {
    $categories[] = [
        'id' => $row['category_id'],
        'name' => $row['category_name'],
    ];
}

// Retrieve selected products from session
$selectedProducts = $_SESSION['selectedProducts'] ?? [];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order System</title>
</head>
<body>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Ordering System</title>
    <style>
        /* Reset basic styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        /* Body and container styling */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            color: #333;
            padding: 8px;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
            display: flex;
            gap: 20px;
        }

        h1, h2, h3 {
            text-align: center;
            margin-bottom: 20px;
            color: #444;
        }

        /* Flexbox layout for three columns */
        .order-list, .categories, .products {
            flex: 1;
            background-color: #fafafa;
            padding: 10px;
            border-radius: 10px;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
        }

        /* Adjust space for categories and products */
        .categories-products {
            display: flex;
            gap: 10px;
            flex: 2;
        }

        /* Order List Table styling */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        table th, table td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: center;
        }

        table th {
            background-color: #f8f8f8;
            font-weight: bold;
        }

        table td {
            background-color: #fcfcfc;
        }

        /* Buttons styling */
        button, .button {
            background-color: #3498db;
            color: white;
            border: none;
            padding: 10px 20px;
            margin: 5px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }

        button:hover, .button:hover {
            background-color: #2980b9;
        }

        /* Product cards styling */
        .product-list {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            justify-content: center;
        }

        .product-card {
            background-color: #f9f9f9;
            border: 1px solid #ddd;
            border-radius: 10px;
            padding: 15px;
            width: 250px;
            text-align: center;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease;
        }

        .product-card:hover {
            transform: translateY(-5px);
        }

        .product-card h4 {
            margin-bottom: 10px;
            font-size: 18px;
        }

        .product-card p {
            margin-bottom: 10px;
            font-size: 16px;
            color: #666;
        }

        .product-card form {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .product-card form input[type="number"] {
            width: 60px;
            padding: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        /* Category buttons */
        .category-buttons {
            display: flex;
            flex-direction: column;
            align-items: flex-start;
        }

        .category-buttons button {
            margin: 5px 0;
            padding: 10px 15px;
            font-size: 14px;
            width: 100%;
        }

        /* Responsive Design */
        @media only screen and (max-width: 768px) {
            .container {
                flex-direction: column;
            }

            .product-list {
                flex-direction: column;
                align-items: center;
            }

            .product-card {
                width: 100%;
            }

            table th, table td {
                font-size: 14px;
            }

            button, .button {
                width: 100%;
                margin-bottom: 10px;
            }

            .category-buttons button {
                width: 100%;
            }
        }

        .quantity-wrapper {
    display: flex;
    align-items: center;
}

.quantity-btn {
    background-color: #f0f0f0; /* Light gray background */
    border: 1px solid #ccc; /* Gray border */
    color: #333; /* Text color */
    padding: 8px 12px; /* Padding for buttons */
    cursor: pointer; /* Cursor style */
    font-size: 16px; /* Font size */
}

.quantity-btn:hover {
    background-color: #e0e0e0; /* Slightly darker on hover */
}

input[type="number"] {
    width: 50px; /* Fixed width for input */
    text-align: center; /* Center the number */
    border: 1px solid #ccc; /* Border for input */
    margin: 0 5px; /* Margin between buttons and input */
    font-size: 16px; /* Font size */
    padding: 5px; /* Padding for input */
}
    </style>

<script>
function changeQuantity(productId, change) {
    const quantityInput = document.getElementById('quantity-' + productId);
    let currentQuantity = parseInt(quantityInput.value);
    currentQuantity += change;
    
    // Ensure quantity doesn't go below 1
    if (currentQuantity < 1) {
        currentQuantity = 1;
    }
    
    quantityInput.value = currentQuantity;
    updateTotal(); // Update total amount after changing quantity
    
    // Optionally, send the updated quantity to the server via AJAX
    updateQuantityOnServer(productId, currentQuantity);
}

function updateTotal() {
    const rows = document.querySelectorAll('.order-list tbody tr');
    let total = 0;
    
    rows.forEach(row => {
        const price = parseFloat(row.cells[1].innerText);
        const quantity = parseInt(row.querySelector('input[type="number"]').value);
        total += price * quantity;
    });
    
    document.getElementById('total-amount').innerText = total.toFixed(2);
}

function deleteProduct(productId) {
    // Remove the product row from the table
    const row = document.querySelector(`tr[data-product-id='${productId}']`);
    if (row) {
        row.remove();
        updateTotal(); // Update total amount after deleting product
        
        // Optionally, send a request to the server to delete the product from the order
        deleteProductFromServer(productId);
    }
}

// Example functions to handle server requests (using fetch API)
// You would implement the corresponding PHP to handle these requests
function updateQuantityOnServer(productId, quantity) {
    fetch('update_quantity.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ productId: productId, quantity: quantity })
    });
}

function deleteProductFromServer(productId) {
    fetch('delete_product.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ productId: productId })
    });
}
</script>

</head>
<body>
<div class="container">
<h2>Selected Table: Table #<?php echo htmlspecialchars($tableNumber); ?></h2>
    <!-- Display Order List on the Left -->
    <div class="order-list">
    <h2>Order List</h2>
    <table>
        <thead>
            <tr>
                <th>Product Name</th>
                <th>Price</th>
                <th>Quantity</th>
                <th>Total</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($selectedProducts as $productId => $product): ?>
                <tr data-product-id="<?php echo $productId; ?>">
                    <td><?php echo htmlspecialchars($product['name']); ?></td>
                    <td><?php echo number_format($product['price'], 2); ?></td>
                    <td>
                        <div class="quantity-wrapper">
                            <button class="quantity-btn minus" onclick="changeQuantity('<?php echo $productId; ?>', -1)">-</button>
                            <input type="number" id="quantity-<?php echo $productId; ?>" value="<?php echo $product['quantity']; ?>" min="1" onchange="updateTotal()" />
                            <button class="quantity-btn plus" onclick="changeQuantity('<?php echo $productId; ?>', 1)">+</button>
                        </div>
                    </td>
                    <td><?php echo number_format($product['price'] * $product['quantity'], 2); ?></td>
                    <td>
                        <button class="delete-btn" onclick="deleteProduct('<?php echo $productId; ?>')">Delete</button>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <h3>Total: $<span id="total-amount"><?php 
        $totalAmount = 0;
        foreach ($selectedProducts as $product) {
            $totalAmount += $product['price'] * $product['quantity'];
        }
        echo number_format($totalAmount, 2);
    ?></span></h3>
    <form action="" method="POST">
        <button type="submit" name="pay">Pay Now</button>
        <button type="submit" name="pay_later">Pay Later</button>
    </form>
</div>

    <!-- Categories and Products Section -->
    <div class="categories-products">
        <div class="categories">
            <h2>Categories</h2>
            <div class="category-buttons">
                <button onclick="location.href='order_system.php?category_id=All'">All</button>
                <?php foreach ($categories as $category): ?>
                    <button onclick="location.href='order_system.php?category_id=<?php echo $category['id']; ?>'">
                        <?php echo $category['name']; ?>
                    </button>
                <?php endforeach; ?>
            </div>
        </div>

        <div class="products">
            <h2>Products</h2>
            <div class="product-list">
                <?php while ($row = $productsResult->fetch_assoc()): ?>
                    <div class="product-card">
                        <h4><?php echo $row['product_name']; ?></h4>
                        <p>Price: $<?php echo number_format($row['price'], 2); ?></p>
                        <form method="POST" action="">
                            <input type="hidden" name="product_id" value="<?php echo $row['product_id']; ?>" />
                            <input type="number" name="quantity" value="1" min="1" />
                            <button type="submit" name="add_to_order">Add to Order</button>
                        </form>
                    </div>
                <?php endwhile; ?>
            </div>
        </div>
    </div>
</div>
</body>
</html>
