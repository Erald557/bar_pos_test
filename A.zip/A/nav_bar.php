<?php
require 'config.php'; // Include database configuration

// Include Font Awesome CSS
echo '<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Project Title</title>
    <style>
        nav {
            background-color: #333; /* Change as needed */
            padding: 15px; /* Increased padding */
            text-align: center; /* Center the contents */
        }

        nav ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            display: inline-flex; /* Aligns the list items in a row */
        }

        nav li {
            margin: 0 30px; /* Increased margin for spacing */
        }

        nav a {
            color: white; /* Change text color */
            text-decoration: none;
            font-size: 20px; /* Increased font size */
        }

        nav a:hover {
            text-decoration: underline;
        }

        nav i {
            margin-right: 8px; /* Space between icon and text */
        }
    </style>
</head>
<body>

<nav>
    <ul>
        <li><a href="index.php"><i class="fas fa-home"></i> Tables</a></li>
        <li><a href="orders.php"><i class="fas fa-receipt"></i> Orders</a></li>
        <li><a href="categories.php"><i class="fas fa-tags"></i> Categories</a></li>
        <li><a href="products.php"><i class="fas fa-box"></i> Products</a></li>
        <li><a href="index.php?page=sales"><i class="fas fa-chart-line"></i> Sales</a></li>
        <li><a href="index.php?page=users"><i class="fas fa-users"></i> Users</a></li>
    </ul>
</nav>



</body>
</html>
