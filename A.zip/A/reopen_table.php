<?php
require 'config.php';
session_start();

// Check if table number is set in the query string
if (!isset($_GET['table_number'])) {
    die("No table number specified.");
}

$tableNumber = $_GET['table_number'];

// Mark the table as unoccupied
$sql = "UPDATE tables SET is_occupied = 0 WHERE table_number = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $tableNumber);
if ($stmt->execute()) {
    // Optionally clear the pending orders if desired
    $deleteOrdersSql = "DELETE FROM pending_orders WHERE table_number = ?";
    $deleteStmt = $conn->prepare($deleteOrdersSql);
    $deleteStmt->bind_param("i", $tableNumber);
    $deleteStmt->execute();
    
    // Redirect to index or order system
    header("Location: index.php");
    exit();
} else {
    echo "Error reopening table: " . $conn->error;
}
