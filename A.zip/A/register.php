<?php
require 'config.php'; // Ensure this is the correct path to your database config
session_start(); // Start the session

// Initialize a variable to store error and success messages
$error = '';
$success = '';

// Check if the form has been submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $email = $_POST['email']; // Get the email from the form

    // Validate username, password, and email (add more validation as needed)
    if (empty($username) || empty($password) || empty($email)) {
        $error = "Username, password, and email are required.";
    } else {
        // Check if the username or email already exists
        $sql = "SELECT * FROM users WHERE username = ? OR email = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ss", $username, $email); // Bind the username and email parameters
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $error = "Username or email already taken."; // Set error message if username or email exists
        } else {
            // Hash the password before storing it
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

            // Insert new user into the database
            $sql = "INSERT INTO users (username, password, email) VALUES (?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sss", $username, $hashedPassword, $email); // Bind parameters
            if ($stmt->execute()) {
                $success = "Registration successful! You can now log in."; // Set success message
            } else {
                $error = "Error registering user: " . $stmt->error; // Set error message if registration fails
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link rel="stylesheet" href="styles.css"> <!-- Link to your CSS file for styling -->
</head>
<body>
    <div class="register-container">
        <h2>Register</h2>
        <?php if ($error): ?> <!-- Display error message if it exists -->
            <p class="error"><?php echo $error; ?></p>
        <?php endif; ?>
        <?php if ($success): ?> <!-- Display success message if it exists -->
            <p class="success"><?php echo $success; ?></p>
        <?php endif; ?>
        <form action="" method="POST">
            <input type="text" name="username" placeholder="Username" required>
            <input type="password" name="password" placeholder="Password" required>
            <input type="email" name="email" placeholder="Email" required> <!-- New email field -->
            <button type="submit">Register</button>
        </form>
        <p>Already have an account? <a href="login.php">Login here</a></p>
    </div>
</body>
</html>