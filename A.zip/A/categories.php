<?php
require 'config.php'; // Include database configuration
require 'nav_bar.php'; // Include the navbar

// Handle adding a new category
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_category'])) {
    $category_name = $conn->real_escape_string($_POST['category_name']);
    
    $sql = "INSERT INTO categories (category_name) VALUES ('$category_name')";
    if ($conn->query($sql) === TRUE) {
    } else {
        echo "<script>alert('Error: " . $conn->error . "');</script>";
    }
}

// Handle deleting a category
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete_category'])) {
    $category_id = (int)$_POST['category_id'];
    
    $sql = "DELETE FROM categories WHERE category_id = $category_id";
    if ($conn->query($sql) === TRUE) {
    } else {
        echo "<script>alert('Error: " . $conn->error . "');</script>";
    }
}

// Fetch existing categories from the database
$sql = "SELECT category_id, category_name, created_at FROM categories";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Categories</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
       body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa; /* Light background color */
        }

        h2 {
            color: #333; /* Dark color for headings */
        }

        .container {
            display: flex;
            justify-content: space-between;
            max-width: 1200px;
            margin: 0 auto;
        }

        .form-container, .table-container {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            flex: 1;
            margin: 0 10px; /* Margin between containers */
        }

        .form-container {
            margin-right: 20px;
        }

        input[type="text"] {
            width: calc(100% - 22px); /* Full width minus padding */
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            margin-bottom: 10px;
        }

        button {
            background-color: #28a745; /* Green for Add */
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: #0056b3; /* Darker shade on hover */
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #007bff; /* Table header color */
            color: white;
        }

        tr:hover {
            background-color: #f1f1f1; /* Highlight on row hover */
        }

        .delete-btn {
            background-color: #dc3545; /* Red for Delete */
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            padding: 8px 16px;
            font-size: 16px;
            transition: background-color 0.3s;
        }

        .delete-btn:hover {
            background-color: #c82333; /* Darker red for hover */
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Add New Category Section -->
        <div class="form-container">
            <h2>Add New Category</h2>
            <form action="" method="POST">
                <input type="text" name="category_name" placeholder="Category Name" required>
                <button type="submit" name="add_category">Add Category</button>
            </form>
        </div>

        <!-- Existing Categories Section -->
        <div class="table-container">
            <h2>Existing Categories</h2>
            <table>
                <tr>
                    <th>Category ID</th>
                    <th>Category Name</th>
                    <th>Actions</th>
                </tr>
                <?php if ($result && $result->num_rows > 0): ?>
                    <?php while ($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?= $row['category_id']; ?></td>
                            <td><?= htmlspecialchars($row['category_name']); ?></td>
                            <td>
                                <form action="" method="POST" onsubmit="return confirm('Are you sure you want to delete this category?');">
                                    <input type="hidden" name="category_id" value="<?= $row['category_id']; ?>">
                                    <button type="submit" name="delete_category" class="delete-btn">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="3">No categories found.</td>
                    </tr>
                <?php endif; ?>
            </table>
        </div>
    </div>
    
    <?php $conn->close(); // Close the database connection ?>
</body>
</html>
